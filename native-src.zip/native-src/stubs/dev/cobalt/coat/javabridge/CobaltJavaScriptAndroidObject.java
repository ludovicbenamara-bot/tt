package dev.cobalt.coat.javabridge;
// Compile-time stub of the interface shipped in the APK.
public interface CobaltJavaScriptAndroidObject {
    String getJavaScriptInterfaceName();
}
