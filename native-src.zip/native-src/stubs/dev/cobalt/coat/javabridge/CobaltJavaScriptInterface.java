package dev.cobalt.coat.javabridge;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
// Compile-time stub of the annotation shipped in the APK.
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface CobaltJavaScriptInterface {
}
