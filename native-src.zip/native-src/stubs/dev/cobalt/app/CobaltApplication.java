package dev.cobalt.app;
// Compile-time stub of the class shipped in the APK.
public class CobaltApplication extends android.app.Application {
}
