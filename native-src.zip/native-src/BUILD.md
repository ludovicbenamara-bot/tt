# Module Android : spectre audio réel

Cobalt joue le son via le lecteur natif de la TV : la page ne peut pas l'analyser.
Ce module capte la sortie audio (android.media.audiofx.Visualizer, session 0) et la
sert au script sur `http://127.0.0.1:47913/bands?n=24` (accessible uniquement depuis la TV).

- `src/` : code ajouté (TizenTubeAudioApp, AudioVisualizerBridge, SpectrumServer).
- `stubs/` : déclarations des classes de l'APK d'origine, pour la compilation seulement.
- `build_base_apk.py` : ajoute le dex à l'APK et remplace la classe Application dans le manifeste.

```bash
AJ=$ANDROID_HOME/platforms/android-35/android.jar
javac -source 8 -target 8 -cp $AJ -d build/stubs $(find stubs -name '*.java')
javac -source 8 -target 8 -cp $AJ:build/stubs -d build/classes $(find src -name '*.java')
d8 --release --min-api 26 --lib $AJ --classpath build/stubs --output build/dex $(find build/classes -name '*.class')
python3 build_base_apk.py cobalt-arm.apk build/dex/classes.dex base.apk
# puis : URL du script, zipalign, apksigner
adb shell pm grant io.gh.reisxd.tizentube.cobalt android.permission.RECORD_AUDIO
```
