package dev.cobalt.app;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Reads MeteoSwiss' public forecast map (the data behind the map on
 * meteosuisse.admin.ch): ~450 places with LV95 coordinates and an 8-day
 * forecast each. Produces the local 5-day forecast (place nearest to the TV)
 * and the conditions for a fixed set of cities shown on the Swiss map.
 * Weather symbols are converted to WMO-like codes, which the page already
 * knows how to draw.
 */
final class MeteoSwissFetcher {
    private static final String BASE = "https://www.meteosuisse.admin.ch/product/output/";
    private static final String PRODUCT = "forecast-map-v2";
    private static final int DAYS = 5;

    // Cities drawn on the map (MeteoSwiss location ids), spread over the country.
    private static final String[] MAP_CITIES = {
        "120100", // Genève
        "100300", // Lausanne
        "140000", // Yverdon-les-Bains
        "400100", // Bâle
        "820000", // Schaffhouse
        "800100", // Zurich
        "900000", // Saint-Gall
        "300400", // Berne
        "600300", // Lucerne
        "195000", // Sion
        "392000", // Zermatt
        "671000", // Biasca
        "690000", // Lugano
        "700000", // Coire
        "750000", // St. Moritz
        "755000", // Scuol
    };

    private MeteoSwissFetcher() { }

    /**
     * @param lv95 TV position in Swiss LV95 coordinates {east, north}, or null.
     * @return {"days":[...], "cities":[...]} or null if MeteoSwiss is unreachable.
     */
    static JSONObject fetch(double[] lv95) throws Exception {
        JSONObject versions = new JSONObject(WeatherFetcher.download(BASE + "versions.json"));
        String version = versions.getString(PRODUCT);
        JSONArray places = new JSONArray(WeatherFetcher.download(
                BASE + PRODUCT + "/version__" + version + "/fr/chmap_current.json"));

        JSONObject nearest = null;
        double best = Double.MAX_VALUE;
        JSONArray cities = new JSONArray();
        for (int i = 0; i < places.length(); i++) {
            JSONObject place = places.getJSONObject(i);
            double x = Double.parseDouble(place.getString("coord_x"));
            double y = Double.parseDouble(place.getString("coord_y"));
            if (lv95 != null && "city".equals(place.optString("location_type"))) {
                double d = Math.hypot(x - lv95[0], y - lv95[1]);
                if (d < best) {
                    best = d;
                    nearest = place;
                }
            }
            String id = place.optString("location_id");
            for (String wanted : MAP_CITIES) {
                if (wanted.equals(id)) {
                    JSONObject today = place.getJSONArray("forecasts").getJSONObject(0);
                    cities.put(new JSONObject()
                            .put("name", place.optString("location_name"))
                            .put("x", x)
                            .put("y", y)
                            .put("code", toWmo(today.getInt("weather_symbol_id")))
                            .put("min", today.getInt("temp_low"))
                            .put("max", today.getInt("temp_high")));
                }
            }
        }

        JSONObject out = new JSONObject().put("cities", cities).put("source", "meteoswiss");
        // Outside Switzerland (or no location): no local forecast from MeteoSwiss.
        if (nearest != null && best < 30000) {
            JSONArray forecasts = nearest.getJSONArray("forecasts");
            JSONArray days = new JSONArray();
            for (int i = 0; i < Math.min(DAYS, forecasts.length()); i++) {
                JSONObject f = forecasts.getJSONObject(i);
                days.put(new JSONObject()
                        .put("date", f.getString("date_iso"))
                        .put("code", toWmo(f.getInt("weather_symbol_id")))
                        .put("max", f.getInt("temp_high"))
                        .put("min", f.getInt("temp_low")));
            }
            out.put("days", days).put("place", nearest.optString("location_name"));
        }
        return out;
    }

    /** WGS84 -> LV95, swisstopo's approximate formulas (about 1 m accuracy). */
    static double[] toLv95(double lat, double lon) {
        double p = (lat * 3600 - 169028.66) / 10000;
        double l = (lon * 3600 - 26782.5) / 10000;
        double east = 2600072.37 + 211455.93 * l - 10938.51 * l * p - 0.36 * l * p * p - 44.54 * l * l * l;
        double north = 1200147.07 + 308807.95 * p + 3745.25 * l * l + 76.63 * p * p
                - 194.56 * l * l * p + 119.79 * p * p * p;
        return new double[] {east, north};
    }

    /** MeteoSwiss weather symbol (night variants are +100) -> WMO weather code. */
    static int toWmo(int symbol) {
        int s = symbol % 100;
        switch (s) {
            case 1: return 0;                         // sunny
            case 2: case 26: return 1;                // mostly sunny, high clouds
            case 3: return 2;                         // partly sunny
            case 4: case 5: case 35: return 3;        // overcast
            case 27: case 28: return 45;              // stratus, fog
            case 8: case 11: case 16: case 19: case 22: case 32: return 71; // snow
            case 12: case 13: case 23: case 24: case 25: return 95;        // thunder
            case 7: case 10: case 15: case 18: case 21: return 66;         // sleet
            default: return 61;                       // rain and showers
        }
    }
}
