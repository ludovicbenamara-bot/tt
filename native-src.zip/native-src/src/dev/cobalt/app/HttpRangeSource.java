package dev.cobalt.app;

import android.media.MediaDataSource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * A remote video for MediaPlayer, read with HTTP range requests over plain
 * sockets: the app blocks cleartext HttpURLConnection (which MediaPlayer
 * would use), and the aerial videos' HTTPS uses a CA Android does not trust.
 * Reads are served from a few cached 2 MB chunks (playback is mostly
 * sequential), so the network sees about one request per chunk.
 */
final class HttpRangeSource extends MediaDataSource {
    private static final int CHUNK = 2 * 1024 * 1024;
    private static final int CACHED_CHUNKS = 3;
    private static final int TIMEOUT_MS = 15000;

    private final String host;
    private final String path;
    private long size = -1;
    private final long[] chunkIndex = new long[CACHED_CHUNKS];
    private final byte[][] chunkData = new byte[CACHED_CHUNKS][];
    private int nextSlot = 0;
    private volatile boolean closed = false;

    HttpRangeSource(String host, String path) {
        this.host = host;
        this.path = path;
        java.util.Arrays.fill(chunkIndex, -1);
    }

    @Override
    public synchronized long getSize() throws IOException {
        if (size < 0) fetch(0, 0);
        return size;
    }

    @Override
    public synchronized int readAt(long position, byte[] buffer, int offset, int length) throws IOException {
        if (closed) throw new IOException("closed");
        long total = getSize();
        if (position >= total) return -1;
        int copied = 0;
        while (copied < length && position + copied < total) {
            long pos = position + copied;
            long index = pos / CHUNK;
            byte[] chunk = chunk(index);
            int inChunk = (int) (pos - index * CHUNK);
            if (inChunk >= chunk.length) break;
            int n = Math.min(length - copied, chunk.length - inChunk);
            System.arraycopy(chunk, inChunk, buffer, offset + copied, n);
            copied += n;
        }
        return copied == 0 ? -1 : copied;
    }

    private byte[] chunk(long index) throws IOException {
        for (int i = 0; i < CACHED_CHUNKS; i++) {
            if (chunkIndex[i] == index) return chunkData[i];
        }
        long start = index * CHUNK;
        long end = Math.min(size, start + CHUNK) - 1;
        byte[] data = fetch(start, end);
        chunkIndex[nextSlot] = index;
        chunkData[nextSlot] = data;
        nextSlot = (nextSlot + 1) % CACHED_CHUNKS;
        return data;
    }

    /** GET bytes [start, end]; also learns the total size from Content-Range. */
    private byte[] fetch(long start, long end) throws IOException {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, 80), TIMEOUT_MS);
            socket.setSoTimeout(TIMEOUT_MS);
            OutputStream out = socket.getOutputStream();
            out.write(("GET " + path + " HTTP/1.1\r\nHost: " + host + "\r\nRange: bytes=" + start + "-" + end
                    + "\r\nUser-Agent: TizenTubeAudio\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            out.flush();
            InputStream in = new java.io.BufferedInputStream(socket.getInputStream(), 65536);
            String status = readLine(in);
            if (status == null || !(status.contains(" 206 ") || status.contains(" 200 "))) {
                throw new IOException("HTTP " + status);
            }
            long length = -1;
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                String lower = line.toLowerCase(java.util.Locale.US);
                if (lower.startsWith("content-range:")) {
                    int slash = line.lastIndexOf('/');
                    if (slash > 0) size = Long.parseLong(line.substring(slash + 1).trim());
                } else if (lower.startsWith("content-length:")) {
                    length = Long.parseLong(line.substring(15).trim());
                }
            }
            if (size < 0 && status.contains(" 200 ")) size = length;
            ByteArrayOutputStream body = new ByteArrayOutputStream((int) Math.max(1, Math.min(length, CHUNK)));
            byte[] buf = new byte[65536];
            long want = length >= 0 ? length : Long.MAX_VALUE;
            int n;
            while (body.size() < want && (n = in.read(buf, 0, (int) Math.min(buf.length, want - body.size()))) > 0) {
                if (closed) throw new IOException("closed");
                body.write(buf, 0, n);
            }
            return body.toByteArray();
        }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        return c < 0 && sb.length() == 0 ? null : sb.toString();
    }

    @Override
    public void close() {
        closed = true;
    }
}
