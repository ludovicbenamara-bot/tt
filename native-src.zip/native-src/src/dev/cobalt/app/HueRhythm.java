package dev.cobalt.app;

import android.util.Log;

/**
 * Makes the Hue light pulse with the music: a native thread watches the bass
 * of the TV's sound output (Android Visualizer, see AudioVisualizerBridge),
 * and on every beat flashes the light to full brightness, then lets it fade
 * back to a dimmer level. Colour is left as set (the artwork's colour).
 * Uses the plain REST API, kept under the bridge's limit (~10 commands per
 * second per light): at most one command every MIN_GAP_MS.
 * Started and stopped by the page (GET /hue/rhythm?on=1&bri=..), which knows
 * when a video is playing and whether the user switched the light off.
 */
final class HueRhythm implements Runnable {
    private static final String TAG = "TTAudio";
    private static final long FRAME_MS = 40;
    private static final long MIN_GAP_MS = 110;
    // A beat: bass clearly above its recent average, and not too soon after the last one.
    private static final float BEAT_RATIO = 1.3f;
    private static final float BEAT_MIN_LEVEL = 0.22f;
    private static final long BEAT_MIN_INTERVAL_MS = 260;
    private static final long FLASH_MS = 90;

    // The page repeats its request every 2 s while music plays; without it
    // (page gone, app in the background) the pulsing stops on its own.
    private static final long KEEPALIVE_MS = 8000;

    private static volatile boolean active = false;
    private static volatile long lastRequest = 0;
    private static volatile int baseBri = 180;
    private static Thread thread = null;

    private HueRhythm() { }

    /** @param bri the user's brightness (1-254); the fade goes down to about half of it. */
    static synchronized String start(int bri) {
        baseBri = Math.max(20, Math.min(254, bri > 0 ? bri : 180));
        lastRequest = System.currentTimeMillis();
        if (active && thread != null && thread.isAlive()) return "ok";
        active = true;
        thread = new Thread(new HueRhythm(), "tt-hue-rhythm");
        thread.setDaemon(true);
        thread.start();
        return "ok";
    }

    static synchronized String stop() {
        active = false;
        return "ok";
    }

    static boolean isActive() {
        return active;
    }

    /** The brightness to report to the page while pulsing (not the flashing value). */
    static int baseBrightness() {
        return baseBri;
    }

    @Override
    public void run() {
        Log.i(TAG, "hue rhythm started");
        float average = 0f;
        long lastBeat = 0;
        long lastSend = 0;
        long dimAt = 0;
        int beats = 0;
        try {
            while (active) {
                long now = System.currentTimeMillis();
                if (now - lastRequest > KEEPALIVE_MS) break;
                float bass = AudioVisualizerBridge.INSTANCE.bassLevel();
                if (bass >= 0) {
                    boolean beat = bass > BEAT_MIN_LEVEL && bass > average * BEAT_RATIO
                            && now - lastBeat > BEAT_MIN_INTERVAL_MS;
                    // Slow running average (about half a second).
                    average = average * 0.92f + bass * 0.08f;
                    if (beat && now - lastSend >= MIN_GAP_MS) {
                        lastBeat = now;
                        lastSend = now;
                        beats++;
                        HueController.setBrightness(254, 0);
                        dimAt = now + FLASH_MS;
                    } else if (dimAt != 0 && now >= dimAt && now - lastSend >= MIN_GAP_MS) {
                        lastSend = now;
                        dimAt = 0;
                        HueController.setBrightness(Math.max(12, baseBri / 2), 3);
                    }
                }
                Thread.sleep(FRAME_MS);
            }
        } catch (Throwable t) {
            Log.w(TAG, "hue rhythm stopped: " + t);
        } finally {
            active = false;
            // Back to the steady brightness the user chose.
            HueController.setBrightness(baseBri, 4);
            Log.i(TAG, "hue rhythm stopped after " + beats + " beats");
        }
    }
}
