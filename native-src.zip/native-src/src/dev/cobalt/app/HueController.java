package dev.cobalt.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.util.Log;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Sets a Philips Hue light to a colour through the local Hue Bridge (v1 API).
 * Bridge address, API key and light id are given once from the computer over
 * adb (a broadcast only the adb shell or the system may send, see
 * {@link #registerConfigReceiver}) and kept in the app's private preferences,
 * so the key never ships in the script or the APK and no web page can change it.
 * Plain HTTP over a socket: the bridge only serves a self-signed certificate
 * over HTTPS, and Android blocks cleartext HttpURLConnection for this app.
 */
final class HueController {
    private static final String TAG = "TTAudio";
    private static final String PREFS = "tt_hue";
    private static final int TIMEOUT_MS = 3000;

    private static Context appContext;

    private HueController() { }

    static final String CONFIG_ACTION = "io.gh.reisxd.tizentube.cobalt.HUE_CONFIG";
    // Held by the adb shell and the system only; ordinary apps cannot get it.
    private static final String CONFIG_PERMISSION = "android.permission.DUMP";
    private static final int RECEIVER_EXPORTED = 0x2;

    static void init(Context context) {
        appContext = context.getApplicationContext();
    }

    /**
     * adb shell am broadcast -a io.gh.reisxd.tizentube.cobalt.HUE_CONFIG \
     *     -p io.gh.reisxd.tizentube.cobalt --es ip IP --es key KEY --es light ID
     */
    static void registerConfigReceiver(Context context) {
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent intent) {
                String result = configure(intent.getStringExtra("ip"), intent.getStringExtra("key"),
                        intent.getStringExtra("light"));
                setResultData(result);
            }
        };
        try {
            context.registerReceiver(receiver, new IntentFilter(CONFIG_ACTION), CONFIG_PERMISSION, null,
                    RECEIVER_EXPORTED);
        } catch (Throwable t) {
            Log.w(TAG, "hue config receiver not registered: " + t);
        }
    }

    private static SharedPreferences prefs() {
        return appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String configure(String ip, String key, String light) {
        if (appContext == null) return "no context";
        if (ip == null || key == null || light == null) return "invalid";
        if (!ip.matches("[0-9.]{7,15}") || !key.matches("[A-Za-z0-9-]{10,64}") || !light.matches("[0-9]{1,3}")) {
            return "invalid";
        }
        prefs().edit().putString("ip", ip).putString("key", key).putString("light", light).remove("bridgeid").apply();
        Log.i(TAG, "hue configured: bridge " + ip + ", light " + light);
        return "ok";
    }

    static String isConfigured() {
        if (appContext == null) return "no";
        return prefs().contains("key") ? "yes" : "no";
    }

    /**
     * Turns the light on in the given sRGB colour.
     * @param bri 1-254, or 0 to derive it from the colour.
     */
    static String setColor(int r, int g, int b, int bri) {
        double[] xy = rgbToXy(r, g, b);
        int level = bri > 0 ? Math.min(254, bri) : brightness(r, g, b);
        return sendState(String.format(Locale.US,
                "{\"on\":true,\"xy\":[%.4f,%.4f],\"bri\":%d,\"transitiontime\":10}",
                xy[0], xy[1], level));
    }

    static String turnOff() {
        return sendState("{\"on\":false,\"transitiontime\":10}");
    }

    /** {"configured":..,"on":..,"bri":..,"name":..,"reachable":..} read from the bridge. */
    static String getState() {
        String[] cfg = config();
        if (cfg == null) return "{\"configured\":false}";
        try {
            String reply = requestWithRelocation("GET", "/lights/" + cfg[2], null);
            int start = reply.indexOf('{');
            int end = reply.lastIndexOf('}');
            if (start < 0 || end < start) return "{\"configured\":true,\"error\":true}";
            JSONObject light = new JSONObject(reply.substring(start, end + 1));
            JSONObject state = light.getJSONObject("state");
            return new JSONObject()
                    .put("configured", true)
                    .put("on", state.optBoolean("on"))
                    .put("bri", state.optInt("bri"))
                    .put("reachable", state.optBoolean("reachable", true))
                    .put("name", light.optString("name"))
                    .toString();
        } catch (Throwable t) {
            Log.w(TAG, "hue state failed: " + t);
            return "{\"configured\":true,\"error\":true}";
        }
    }

    private static String[] config() {
        if (appContext == null) return null;
        SharedPreferences p = prefs();
        String ip = p.getString("ip", null);
        String key = p.getString("key", null);
        String light = p.getString("light", null);
        if (ip == null || key == null || light == null) return null;
        return new String[] {ip, key, light};
    }

    private static String sendState(String body) {
        String[] cfg = config();
        if (cfg == null) return "not configured";
        try {
            String reply = requestWithRelocation("PUT", "/lights/" + cfg[2] + "/state", body);
            return reply.contains("\"success\"") ? "ok" : reply;
        } catch (Throwable t) {
            Log.w(TAG, "hue request failed: " + t);
            return "error: " + t;
        }
    }

    private static int brightness(int r, int g, int b) {
        int max = Math.max(r, Math.max(g, b));
        // Keep the strip clearly lit even for dark artwork colours.
        return Math.max(120, Math.min(254, Math.round(max / 255f * 254)));
    }

    /** sRGB -> CIE 1931 xy (Philips' recommended conversion, wide gamut). */
    static double[] rgbToXy(int r8, int g8, int b8) {
        double r = linear(r8 / 255.0);
        double g = linear(g8 / 255.0);
        double b = linear(b8 / 255.0);
        double x = r * 0.664511 + g * 0.154324 + b * 0.162028;
        double y = r * 0.283881 + g * 0.668433 + b * 0.047685;
        double z = r * 0.000088 + g * 0.072310 + b * 0.986039;
        double sum = x + y + z;
        if (sum <= 0) return new double[] {0.3227, 0.3290};
        return new double[] {x / sum, y / sum};
    }

    private static double linear(double c) {
        return c > 0.04045 ? Math.pow((c + 0.055) / 1.055, 2.4) : c / 12.92;
    }

    /**
     * Sends an API request (path after /api/KEY) to the saved bridge. If the
     * bridge does not answer, looks for it again on the local network (its
     * address may have changed) and retries once.
     */
    private static String requestWithRelocation(String method, String apiPath, String body) throws Exception {
        String[] cfg = config();
        try {
            String reply = request(method, cfg[0], "/api/" + cfg[1] + apiPath, body);
            rememberBridgeId(cfg[0]);
            return reply;
        } catch (java.io.IOException e) {
            String found = relocate(cfg[0]);
            if (found == null) throw e;
            return request(method, found, "/api/" + cfg[1] + apiPath, body);
        }
    }

    // The bridge answers GET /api/config without a key; its id tells it apart from other bridges.
    private static void rememberBridgeId(String ip) {
        if (prefs().contains("bridgeid")) return;
        try {
            String id = bridgeIdAt(ip, TIMEOUT_MS);
            if (id != null) prefs().edit().putString("bridgeid", id).apply();
        } catch (Throwable ignored) { }
    }

    private static String bridgeIdAt(String ip, int timeoutMs) throws Exception {
        String reply = request("GET", ip, "/api/config", null, timeoutMs);
        int start = reply.indexOf('{');
        int end = reply.lastIndexOf('}');
        if (start < 0 || end < start) return null;
        String id = new JSONObject(reply.substring(start, end + 1)).optString("bridgeid", "");
        return id.isEmpty() ? null : id;
    }

    private static final long RELOCATE_INTERVAL_MS = 2 * 60 * 1000;
    private static final int SCAN_TIMEOUT_MS = 600;
    private static long lastRelocateAt = 0;

    /** Scans the local /24 networks for the saved bridge; saves and returns its new address. */
    private static synchronized String relocate(String oldIp) {
        long now = System.currentTimeMillis();
        if (now - lastRelocateAt < RELOCATE_INTERVAL_MS) return null;
        lastRelocateAt = now;
        final String wantedId = prefs().getString("bridgeid", null);
        java.util.LinkedHashSet<String> prefixes = new java.util.LinkedHashSet<>();
        int dot = oldIp.lastIndexOf('.');
        if (dot > 0) prefixes.add(oldIp.substring(0, dot + 1));
        try {
            for (java.net.NetworkInterface nif : java.util.Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                for (java.net.InetAddress addr : java.util.Collections.list(nif.getInetAddresses())) {
                    if (addr instanceof java.net.Inet4Address && !addr.isLoopbackAddress()) {
                        String a = addr.getHostAddress();
                        prefixes.add(a.substring(0, a.lastIndexOf('.') + 1));
                    }
                }
            }
        } catch (Throwable ignored) { }
        Log.i(TAG, "hue bridge not answering at " + oldIp + ", scanning " + prefixes);
        java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(32);
        try {
            java.util.concurrent.ExecutorCompletionService<String> done = new java.util.concurrent.ExecutorCompletionService<>(pool);
            int jobs = 0;
            for (String prefix : prefixes) {
                for (int host = 1; host <= 254; host++) {
                    final String ip = prefix + host;
                    if (ip.equals(oldIp)) continue;
                    done.submit(() -> {
                        try {
                            String id = bridgeIdAt(ip, SCAN_TIMEOUT_MS);
                            if (id != null && (wantedId == null || wantedId.equals(id))) return ip;
                        } catch (Throwable ignored) { }
                        return null;
                    });
                    jobs++;
                }
            }
            for (int i = 0; i < jobs; i++) {
                String ip = done.take().get();
                if (ip != null) {
                    prefs().edit().putString("ip", ip).apply();
                    Log.i(TAG, "hue bridge found at " + ip);
                    return ip;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "hue bridge scan failed: " + t);
        } finally {
            pool.shutdownNow();
        }
        Log.w(TAG, "hue bridge not found on the local network");
        return null;
    }

    private static String request(String method, String ip, String path, String body) throws Exception {
        return request(method, ip, path, body, TIMEOUT_MS);
    }

    private static String request(String method, String ip, String path, String body, int timeoutMs) throws Exception {
        byte[] payload = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(ip, 80), timeoutMs);
            socket.setSoTimeout(timeoutMs);
            OutputStream out = socket.getOutputStream();
            String head = method + " " + path + " HTTP/1.1\r\n"
                    + "Host: " + ip + "\r\n"
                    + "Content-Type: application/json\r\n"
                    + "Content-Length: " + payload.length + "\r\n"
                    + "Connection: close\r\n\r\n";
            out.write(head.getBytes(StandardCharsets.US_ASCII));
            out.write(payload);
            out.flush();
            InputStream in = socket.getInputStream();
            StringBuilder reply = new StringBuilder();
            byte[] buf = new byte[1024];
            int n;
            while ((n = in.read(buf)) > 0 && reply.length() < 16384) {
                reply.append(new String(buf, 0, n, StandardCharsets.UTF_8));
            }
            return reply.toString();
        }
    }
}
