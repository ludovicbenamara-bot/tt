package dev.cobalt.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Sets a Philips Hue light to a colour through the local Hue Bridge (v1 API).
 * Bridge address, API key and light id are given once from the computer
 * (GET /hue/config?ip=..&key=..&light=..) and kept in the app's private
 * preferences, so the key never ships in the script or the APK.
 * Plain HTTP over a socket: the bridge only serves a self-signed certificate
 * over HTTPS, and Android blocks cleartext HttpURLConnection for this app.
 */
final class HueController {
    private static final String TAG = "TTAudio";
    private static final String PREFS = "tt_hue";
    private static final int TIMEOUT_MS = 3000;

    private static Context appContext;

    private HueController() { }

    static void init(Context context) {
        appContext = context.getApplicationContext();
    }

    private static SharedPreferences prefs() {
        return appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String configure(String ip, String key, String light) {
        if (appContext == null) return "no context";
        if (!ip.matches("[0-9.]{7,15}") || !key.matches("[A-Za-z0-9-]{10,64}") || !light.matches("[0-9]{1,3}")) {
            return "invalid";
        }
        prefs().edit().putString("ip", ip).putString("key", key).putString("light", light).apply();
        Log.i(TAG, "hue configured: bridge " + ip + ", light " + light);
        return "ok";
    }

    static String isConfigured() {
        if (appContext == null) return "no";
        return prefs().contains("key") ? "yes" : "no";
    }

    /**
     * Turns the light on in the given sRGB colour.
     * @param bri 1-254, or 0 to derive it from the colour.
     */
    static String setColor(int r, int g, int b, int bri) {
        double[] xy = rgbToXy(r, g, b);
        int level = bri > 0 ? Math.min(254, bri) : brightness(r, g, b);
        return sendState(String.format(Locale.US,
                "{\"on\":true,\"xy\":[%.4f,%.4f],\"bri\":%d,\"transitiontime\":10}",
                xy[0], xy[1], level));
    }

    static String turnOff() {
        return sendState("{\"on\":false,\"transitiontime\":10}");
    }

    /** {"configured":..,"on":..,"bri":..,"name":..,"reachable":..} read from the bridge. */
    static String getState() {
        String[] cfg = config();
        if (cfg == null) return "{\"configured\":false}";
        try {
            String reply = request("GET", cfg[0], "/api/" + cfg[1] + "/lights/" + cfg[2], null);
            int start = reply.indexOf('{');
            int end = reply.lastIndexOf('}');
            if (start < 0 || end < start) return "{\"configured\":true,\"error\":true}";
            JSONObject light = new JSONObject(reply.substring(start, end + 1));
            JSONObject state = light.getJSONObject("state");
            return new JSONObject()
                    .put("configured", true)
                    .put("on", state.optBoolean("on"))
                    .put("bri", state.optInt("bri"))
                    .put("reachable", state.optBoolean("reachable", true))
                    .put("name", light.optString("name"))
                    .toString();
        } catch (Throwable t) {
            Log.w(TAG, "hue state failed: " + t);
            return "{\"configured\":true,\"error\":true}";
        }
    }

    private static String[] config() {
        if (appContext == null) return null;
        SharedPreferences p = prefs();
        String ip = p.getString("ip", null);
        String key = p.getString("key", null);
        String light = p.getString("light", null);
        if (ip == null || key == null || light == null) return null;
        return new String[] {ip, key, light};
    }

    private static String sendState(String body) {
        String[] cfg = config();
        if (cfg == null) return "not configured";
        try {
            String reply = request("PUT", cfg[0], "/api/" + cfg[1] + "/lights/" + cfg[2] + "/state", body);
            return reply.contains("\"success\"") ? "ok" : reply;
        } catch (Throwable t) {
            Log.w(TAG, "hue request failed: " + t);
            return "error: " + t;
        }
    }

    private static int brightness(int r, int g, int b) {
        int max = Math.max(r, Math.max(g, b));
        // Keep the strip clearly lit even for dark artwork colours.
        return Math.max(120, Math.min(254, Math.round(max / 255f * 254)));
    }

    /** sRGB -> CIE 1931 xy (Philips' recommended conversion, wide gamut). */
    static double[] rgbToXy(int r8, int g8, int b8) {
        double r = linear(r8 / 255.0);
        double g = linear(g8 / 255.0);
        double b = linear(b8 / 255.0);
        double x = r * 0.664511 + g * 0.154324 + b * 0.162028;
        double y = r * 0.283881 + g * 0.668433 + b * 0.047685;
        double z = r * 0.000088 + g * 0.072310 + b * 0.986039;
        double sum = x + y + z;
        if (sum <= 0) return new double[] {0.3227, 0.3290};
        return new double[] {x / sum, y / sum};
    }

    private static double linear(double c) {
        return c > 0.04045 ? Math.pow((c + 0.055) / 1.055, 2.4) : c / 12.92;
    }

    private static String request(String method, String ip, String path, String body) throws Exception {
        byte[] payload = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(ip, 80), TIMEOUT_MS);
            socket.setSoTimeout(TIMEOUT_MS);
            OutputStream out = socket.getOutputStream();
            String head = method + " " + path + " HTTP/1.1\r\n"
                    + "Host: " + ip + "\r\n"
                    + "Content-Type: application/json\r\n"
                    + "Content-Length: " + payload.length + "\r\n"
                    + "Connection: close\r\n\r\n";
            out.write(head.getBytes(StandardCharsets.US_ASCII));
            out.write(payload);
            out.flush();
            InputStream in = socket.getInputStream();
            StringBuilder reply = new StringBuilder();
            byte[] buf = new byte[1024];
            int n;
            while ((n = in.read(buf)) > 0 && reply.length() < 16384) {
                reply.append(new String(buf, 0, n, StandardCharsets.UTF_8));
            }
            return reply.toString();
        }
    }
}
