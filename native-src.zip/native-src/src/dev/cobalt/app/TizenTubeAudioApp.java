package dev.cobalt.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;
import java.lang.reflect.Field;
import java.util.List;

/**
 * Replaces CobaltApplication in the manifest (same-length name, so the binary
 * manifest can be patched in place). Starts {@link SpectrumServer}, which the
 * userscript polls for the live spectrum. Also registers
 * {@link AudioVisualizerBridge} as a Cobalt Java bridge object
 * (window.TTAudioVisualizer), for pages that can see those objects.
 */
public class TizenTubeAudioApp extends CobaltApplication {
    private static final String TAG = "TTAudio";
    private static final String OBJECT_LIST_FIELD = "mJavaScriptAndroidObjectList";

    @Override
    public void onCreate() {
        super.onCreate();
        SpectrumServer.start();
        registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override
            public void onActivityPreCreated(Activity activity, Bundle savedInstanceState) {
                addBridge(activity);
            }

            @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) { }
            @Override public void onActivityStarted(Activity activity) { }
            @Override public void onActivityResumed(Activity activity) { }
            @Override public void onActivityPaused(Activity activity) { }
            @Override public void onActivityStopped(Activity activity) { }
            @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) { }
            @Override public void onActivityDestroyed(Activity activity) { }
        });
    }

    @SuppressWarnings("unchecked")
    private static void addBridge(Activity activity) {
        // The field lives on dev.cobalt.coat.CobaltActivity, a superclass of the app's activity.
        for (Class<?> c = activity.getClass(); c != null; c = c.getSuperclass()) {
            try {
                Field field = c.getDeclaredField(OBJECT_LIST_FIELD);
                field.setAccessible(true);
                List<Object> list = (List<Object>) field.get(activity);
                if (list != null && !list.contains(AudioVisualizerBridge.INSTANCE)) {
                    list.add(AudioVisualizerBridge.INSTANCE);
                    Log.i(TAG, "audio visualizer bridge registered on " + c.getName());
                }
                return;
            } catch (NoSuchFieldException e) {
                // Keep walking up the class hierarchy.
            } catch (Throwable t) {
                Log.w(TAG, "could not register audio visualizer bridge", t);
                return;
            }
        }
    }
}
