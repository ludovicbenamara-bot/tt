package dev.cobalt.app;

import android.util.Base64;
import android.util.Log;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Pushes the live spectrum to the page over one WebSocket connection
 * (ws://127.0.0.1:47913/bands-stream?n=24), 20 times a second, instead of the
 * page opening a new HTTP connection for every frame. Ends when the page
 * closes the connection (audio screen left). Origin and Host are checked by
 * SpectrumServer before the upgrade.
 */
final class BandStream implements Runnable {
    private static final String TAG = "TTAudio";
    private static final String WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    private static final long FRAME_MS = 50;
    // At most a few pages at once (a page that vanished without closing is dropped on the next write).
    private static final int MAX_STREAMS = 4;
    private static int openStreams = 0;

    private final Socket socket;
    private final int count;

    private BandStream(Socket socket, int count) {
        this.socket = socket;
        this.count = count;
    }

    static void start(Socket socket, String key, int count) throws Exception {
        synchronized (BandStream.class) {
            if (openStreams >= MAX_STREAMS) {
                socket.close();
                return;
            }
            openStreams++;
        }
        String accept = Base64.encodeToString(
                MessageDigest.getInstance("SHA-1").digest((key + WS_GUID).getBytes(StandardCharsets.US_ASCII)),
                Base64.NO_WRAP);
        OutputStream out = socket.getOutputStream();
        out.write(("HTTP/1.1 101 Switching Protocols\r\n"
                + "Upgrade: websocket\r\n"
                + "Connection: Upgrade\r\n"
                + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
        out.flush();
        socket.setTcpNoDelay(true);
        Thread thread = new Thread(new BandStream(socket, count), "tt-band-stream");
        thread.setDaemon(true);
        thread.start();
    }

    @Override
    public void run() {
        Log.i(TAG, "spectrum stream opened");
        int frames = 0;
        try (Socket s = socket) {
            OutputStream out = s.getOutputStream();
            while (true) {
                byte[] payload = AudioVisualizerBridge.INSTANCE.getBands(count).getBytes(StandardCharsets.US_ASCII);
                out.write(frameHeader(payload.length));
                out.write(payload);
                out.flush();
                frames++;
                Thread.sleep(FRAME_MS);
            }
        } catch (Throwable t) {
            // Page closed the connection.
        } finally {
            synchronized (BandStream.class) {
                openStreams--;
            }
            Log.i(TAG, "spectrum stream closed after " + frames + " frames");
        }
    }

    /** Unmasked text frame header (server to client). */
    private static byte[] frameHeader(int length) {
        if (length < 126) return new byte[] {(byte) 0x81, (byte) length};
        return new byte[] {(byte) 0x81, 126, (byte) (length >> 8), (byte) length};
    }
}
