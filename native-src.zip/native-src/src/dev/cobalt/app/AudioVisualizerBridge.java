package dev.cobalt.app;

import android.media.audiofx.Visualizer;
import android.util.Log;
import dev.cobalt.coat.javabridge.CobaltJavaScriptAndroidObject;
import dev.cobalt.coat.javabridge.CobaltJavaScriptInterface;

/**
 * Exposes the real audio spectrum of the TV's output mix to the page, as
 * window.TTAudioVisualizer. Cobalt plays sound through the platform's native
 * player, so Web Audio in the page never sees it; Android's Visualizer on
 * session 0 (the output mix) does. Needs RECORD_AUDIO (declared in the
 * manifest; granted with `adb shell pm grant`).
 */
public final class AudioVisualizerBridge implements CobaltJavaScriptAndroidObject {
    static final AudioVisualizerBridge INSTANCE = new AudioVisualizerBridge();

    private static final String TAG = "TTAudio";
    private static final float MIN_HZ = 40f;
    private static final float MAX_HZ = 14000f;
    // Magnitudes in dB are mapped from [FLOOR_DB, FLOOR_DB + RANGE_DB] to [0, 255].
    private static final float FLOOR_DB = 8f;
    private static final float RANGE_DB = 36f;

    private Visualizer visualizer;
    private byte[] fft;
    private String status = "idle";
    // After a failure, wait before trying to create the Visualizer again.
    private long retryAfter = 0;

    private AudioVisualizerBridge() { }

    @Override
    public String getJavaScriptInterfaceName() {
        return "TTAudioVisualizer";
    }

    /** "ok", "idle" or the last error, for diagnostics. */
    @CobaltJavaScriptInterface
    public synchronized String getStatus() {
        return status;
    }

    /**
     * Current spectrum as {@code count} comma-separated levels (0-255), from
     * low to high frequencies on a log scale. Empty string if unavailable.
     */
    @CobaltJavaScriptInterface
    public synchronized String getBands(int count) {
        if (count < 1 || count > 64 || !ensureVisualizer()) return "";
        try {
            if (visualizer.getFft(fft) != Visualizer.SUCCESS) return "";
        } catch (Throwable t) {
            fail("getFft", t);
            return "";
        }
        int bins = fft.length / 2;
        // Visualizer reports the sampling rate in milliHertz.
        float hzPerBin = visualizer.getSamplingRate() / 1000f / fft.length;
        StringBuilder out = new StringBuilder(count * 4);
        for (int b = 0; b < count; b++) {
            float loHz = (float) (MIN_HZ * Math.pow(MAX_HZ / MIN_HZ, (double) b / count));
            float hiHz = (float) (MIN_HZ * Math.pow(MAX_HZ / MIN_HZ, (double) (b + 1) / count));
            int lo = Math.max(1, Math.min(bins - 1, Math.round(loHz / hzPerBin)));
            int hi = Math.max(lo + 1, Math.min(bins, Math.round(hiHz / hzPerBin)));
            float peak = 0f;
            for (int k = lo; k < hi; k++) {
                float re = fft[2 * k];
                float im = fft[2 * k + 1];
                peak = Math.max(peak, (float) Math.sqrt(re * re + im * im));
            }
            float db = (float) (20 * Math.log10(peak + 1));
            int level = Math.round(Math.max(0f, Math.min(1f, (db - FLOOR_DB) / RANGE_DB)) * 255);
            if (b > 0) out.append(',');
            out.append(level);
        }
        return out.toString();
    }

    private boolean ensureVisualizer() {
        if (visualizer != null) return true;
        if (System.currentTimeMillis() < retryAfter) return false;
        try {
            Visualizer v = new Visualizer(0);
            v.setEnabled(false);
            int[] range = Visualizer.getCaptureSizeRange();
            v.setCaptureSize(Math.min(1024, range[1]));
            v.setScalingMode(Visualizer.SCALING_MODE_NORMALIZED);
            v.setEnabled(true);
            fft = new byte[v.getCaptureSize()];
            visualizer = v;
            status = "ok";
            Log.i(TAG, "visualizer ready, capture size " + fft.length);
            return true;
        } catch (Throwable t) {
            fail("init", t);
            return false;
        }
    }

    private void fail(String where, Throwable t) {
        status = where + ": " + t;
        retryAfter = System.currentTimeMillis() + 5000;
        Log.w(TAG, "visualizer " + status);
        if (visualizer != null) {
            try {
                visualizer.release();
            } catch (Throwable ignored) { }
            visualizer = null;
        }
    }
}
