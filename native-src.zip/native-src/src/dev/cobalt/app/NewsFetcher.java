package dev.cobalt.app;

import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Science headlines for the audio screen's news ticker: the RSS feed of
 * Reddit's r/science (the page itself cannot reach Reddit), and the text of
 * the article a post links to, for reading it on the TV. Reddit limits
 * anonymous clients, so the feed is read at most every 30 minutes, and after
 * a refusal (HTTP 429) the app waits longer before trying again.
 */
final class NewsFetcher {
    private static final String TAG = "TTAudio";
    private static final String FEED = "https://www.reddit.com/r/science/.rss";
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android) TizenTubeAudio/1.0";
    private static final long TTL_MS = 30 * 60 * 1000;
    private static final long BACKOFF_MS = 15 * 60 * 1000;
    private static final int MAX_ITEMS = 25;
    private static final Pattern ENTRY = Pattern.compile("<entry>(.*?)</entry>", Pattern.DOTALL);
    private static final Pattern TITLE = Pattern.compile("<title>(.*?)</title>", Pattern.DOTALL);
    private static final Pattern UPDATED = Pattern.compile("<updated>(.*?)</updated>");
    private static final Pattern CONTENT = Pattern.compile("<content[^>]*>(.*?)</content>", Pattern.DOTALL);
    // In a post's content: the "[link]" anchor points to the source article.
    private static final Pattern SOURCE_LINK = Pattern.compile("<a href=\"([^\"]+)\">\\[link\\]</a>");
    private static final Pattern PARAGRAPH = Pattern.compile("<p\\b[^>]*>(.*?)</p>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
    private static final Pattern NOISE = Pattern.compile(
            "<(script|style|noscript|nav|header|footer|aside|figure|form)\\b.*?</\\1>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
    private static final int MAX_PARAGRAPHS = 40;
    private static final int MAX_ARTICLE_CHARS = 14000;

    // Per headline: {title, source article URL or "", Reddit post URL}.
    private static java.util.List<String[]> entries = new java.util.ArrayList<>();
    private static final java.util.Map<String, String> articles = new java.util.HashMap<>();

    private static String cached = null;
    private static long fetchedAt = 0;
    private static long retryAfter = 0;

    private NewsFetcher() { }

    /** {"source":"r/science","items":[{"title":..,"date":..}, ...]} or {"items":[]}. */
    static synchronized String get() {
        long now = System.currentTimeMillis();
        if (cached != null && now - fetchedAt < TTL_MS) return cached;
        if (now < retryAfter) return cached != null ? cached : "{\"items\":[]}";
        try {
            String xml = download(FEED);
            JSONArray items = new JSONArray();
            java.util.List<String[]> found = new java.util.ArrayList<>();
            Matcher entryMatcher = ENTRY.matcher(xml);
            while (entryMatcher.find() && items.length() < MAX_ITEMS) {
                String entry = entryMatcher.group(1);
                Matcher t = TITLE.matcher(entry);
                if (!t.find()) continue;
                String title = unescape(t.group(1)).trim();
                Matcher u = UPDATED.matcher(entry);
                String link = "";
                Matcher c = CONTENT.matcher(entry);
                if (c.find()) {
                    Matcher l = SOURCE_LINK.matcher(unescape(c.group(1)));
                    if (l.find()) link = unescape(l.group(1));
                }
                Matcher post = Pattern.compile("<link href=\"([^\"]+)\"").matcher(entry);
                found.add(new String[] {title, link, post.find() ? post.group(1) : ""});
                items.put(new JSONObject()
                        .put("title", title)
                        .put("date", u.find() ? u.group(1) : ""));
            }
            if (items.length() > 0) {
                entries = found;
                cached = new JSONObject().put("source", "r/science").put("items", items).toString();
                fetchedAt = now;
            }
        } catch (Throwable t) {
            retryAfter = now + BACKOFF_MS;
            Log.w(TAG, "news feed failed: " + t);
        }
        return cached != null ? cached : "{\"items\":[]}";
    }

    /**
     * {"title":..,"site":..,"paragraphs":[...],"full":true|false} for headline i:
     * the source article's text, or just the headline when the article cannot
     * be read (paywall, blocked, Reddit-only post).
     */
    static synchronized String article(int i) {
        if (i < 0 || i >= entries.size()) return "{\"paragraphs\":[]}";
        String[] e = entries.get(i);
        String key = e[1].isEmpty() ? e[2] : e[1];
        String cachedArticle = articles.get(key);
        if (cachedArticle != null) return cachedArticle;
        JSONArray paragraphs = new JSONArray();
        String site = "reddit.com/r/science";
        boolean full = false;
        if (!e[1].isEmpty() && !e[1].contains("reddit.com")) {
            try {
                site = new URL(e[1]).getHost().replaceFirst("^www\\.", "");
                String page = NOISE.matcher(download(e[1])).replaceAll(" ");
                Matcher p = PARAGRAPH.matcher(page);
                int chars = 0;
                while (p.find() && paragraphs.length() < MAX_PARAGRAPHS && chars < MAX_ARTICLE_CHARS) {
                    String text = unescape(p.group(1).replaceAll("<[^>]+>", "")).replaceAll("\\s+", " ").trim();
                    if (text.length() < 60) continue;
                    paragraphs.put(text);
                    chars += text.length();
                }
                full = paragraphs.length() >= 3;
            } catch (Throwable t) {
                Log.w(TAG, "article failed: " + t);
            }
        }
        if (!full) {
            paragraphs = new JSONArray();
            paragraphs.put(e[0]);
        }
        try {
            String json = new JSONObject().put("title", e[0]).put("site", site)
                    .put("paragraphs", paragraphs).put("full", full).toString();
            if (full) articles.put(key, json);
            return json;
        } catch (Exception ex) {
            return "{\"paragraphs\":[]}";
        }
    }

    private static String unescape(String s) {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&#x27;", "'").replace("&#32;", " ").replace("&nbsp;", " ")
                .replace("&rsquo;", "\u2019").replace("&lsquo;", "\u2018").replace("&ldquo;", "\u201c")
                .replace("&rdquo;", "\u201d").replace("&mdash;", "\u2014").replace("&ndash;", "\u2013")
                .replace("&amp;", "&");
    }

    private static String download(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("User-Agent", USER_AGENT);
        conn.setInstanceFollowRedirects(true);
        try {
            int code = conn.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            try (InputStream in = conn.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return new String(out.toByteArray(), "UTF-8");
            }
        } finally {
            conn.disconnect();
        }
    }
}
