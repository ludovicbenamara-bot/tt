package dev.cobalt.app;

import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Tiny HTTP server on 127.0.0.1 that serves the live spectrum to the page.
 * The page cannot see Java bridge objects from the userscript, but YouTube's
 * CSP allows connect-src to http://127.0.0.1:*, so the script polls
 * GET http://127.0.0.1:PORT/bands?n=24 and gets "12,40,255,...".
 * Bound to the loopback interface only: nothing outside the TV can reach it.
 */
final class SpectrumServer implements Runnable {
    static final int PORT = 47913;
    private static final String TAG = "TTAudio";
    private static boolean pageSeen = false;

    static void start() {
        Thread thread = new Thread(new SpectrumServer(), "tt-spectrum-server");
        thread.setDaemon(true);
        thread.start();
    }

    @Override
    public void run() {
        try (ServerSocket server = new ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))) {
            Log.i(TAG, "spectrum server listening on 127.0.0.1:" + PORT);
            while (true) {
                try (Socket socket = server.accept()) {
                    socket.setSoTimeout(2000);
                    handle(socket);
                } catch (Throwable t) {
                    Log.w(TAG, "spectrum request failed: " + t);
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "spectrum server stopped: " + t);
        }
    }

    private static void handle(Socket socket) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.US_ASCII));
        String requestLine = in.readLine();
        if (requestLine == null) return;
        // Skip the headers.
        String line;
        while ((line = in.readLine()) != null && !line.isEmpty()) { }

        String[] parts = requestLine.split(" ");
        String method = parts.length > 0 ? parts[0] : "";
        String path = parts.length > 1 ? parts[1] : "";

        String body;
        int code = 200;
        if ("OPTIONS".equals(method)) {
            body = "";
        } else if (path.startsWith("/bands")) {
            if (!pageSeen && path.contains("from=page")) {
                pageSeen = true;
                Log.i(TAG, "first spectrum request from the page");
            }
            body = AudioVisualizerBridge.INSTANCE.getBands(parseCount(path));
        } else if (path.startsWith("/hue/config")) {
            body = HueController.configure(param(path, "ip"), param(path, "key"), param(path, "light"));
        } else if (path.startsWith("/hue/status")) {
            body = HueController.isConfigured();
        } else if (path.startsWith("/hue")) {
            body = HueController.setColor(parseInt(param(path, "r")), parseInt(param(path, "g")), parseInt(param(path, "b")));
        } else if (path.startsWith("/weather")) {
            body = WeatherFetcher.get();
        } else if (path.startsWith("/status")) {
            body = AudioVisualizerBridge.INSTANCE.getStatus();
        } else {
            code = 404;
            body = "";
        }

        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        String headers = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Not Found") + "\r\n"
                + "Content-Type: text/plain\r\n"
                + "Content-Length: " + bytes.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Access-Control-Allow-Origin: *\r\n"
                + "Access-Control-Allow-Methods: GET, OPTIONS\r\n"
                // Chrome's Private Network Access preflight for public page -> localhost.
                + "Access-Control-Allow-Private-Network: true\r\n"
                + "Connection: close\r\n\r\n";
        OutputStream out = socket.getOutputStream();
        out.write(headers.getBytes(StandardCharsets.US_ASCII));
        out.write(bytes);
        out.flush();
    }

    private static String param(String path, String name) {
        int q = path.indexOf('?');
        if (q < 0) return "";
        for (String pair : path.substring(q + 1).split("&")) {
            int eq = pair.indexOf('=');
            if (eq > 0 && pair.substring(0, eq).equals(name)) return pair.substring(eq + 1);
        }
        return "";
    }

    private static int parseInt(String value) {
        try {
            return Math.max(0, Math.min(255, Integer.parseInt(value)));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static int parseCount(String path) {
        int i = path.indexOf("n=");
        if (i < 0) return 24;
        int end = i + 2;
        while (end < path.length() && Character.isDigit(path.charAt(end))) end++;
        try {
            return Integer.parseInt(path.substring(i + 2, end));
        } catch (NumberFormatException e) {
            return 24;
        }
    }
}
