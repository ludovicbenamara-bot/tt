package dev.cobalt.app;

import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Fetches the 5-day forecast for the page. Native code is not bound by
 * YouTube's CSP, so it can reach Open-Meteo directly (the Google Sheet relay
 * gets throttled by Open-Meteo from time to time). Location comes from the
 * TV's public IP via ipwho.is, cached for the app's lifetime.
 * Served by {@link SpectrumServer} as GET /weather:
 * {"days":[{"date":"2026-11-14","code":61,"max":11,"min":6},...]}
 */
final class WeatherFetcher {
    private static final String TAG = "TTAudio";
    private static final long CACHE_MS = 30 * 60 * 1000;
    private static final int TIMEOUT_MS = 8000;
    // Used when the IP lookup fails.
    private static final double DEFAULT_LAT = 46.52;
    private static final double DEFAULT_LON = 6.50;

    private static String cachedJson = "";
    private static long cachedAt = 0;
    private static double[] location;

    static synchronized String get() {
        long now = System.currentTimeMillis();
        if (!cachedJson.isEmpty() && now - cachedAt < CACHE_MS) return cachedJson;
        try {
            double[] loc = locate();
            String url = String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.2f&longitude=%.2f"
                            + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                            + "&timezone=auto&forecast_days=5",
                    loc[0], loc[1]);
            JSONObject daily = new JSONObject(download(url)).getJSONObject("daily");
            JSONArray dates = daily.getJSONArray("time");
            JSONArray codes = daily.getJSONArray("weather_code");
            JSONArray max = daily.getJSONArray("temperature_2m_max");
            JSONArray min = daily.getJSONArray("temperature_2m_min");
            JSONArray days = new JSONArray();
            for (int i = 0; i < dates.length(); i++) {
                JSONObject day = new JSONObject();
                day.put("date", dates.getString(i));
                day.put("code", codes.getInt(i));
                day.put("max", Math.round(max.getDouble(i)));
                day.put("min", Math.round(min.getDouble(i)));
                days.put(day);
            }
            cachedJson = new JSONObject().put("days", days).toString();
            cachedAt = now;
        } catch (Throwable t) {
            // Keep serving the last good forecast; the page drops past days.
            Log.w(TAG, "weather fetch failed: " + t);
        }
        return cachedJson;
    }

    private static double[] locate() {
        if (location != null) return location;
        try {
            JSONObject geo = new JSONObject(download("https://ipwho.is/?fields=success,latitude,longitude"));
            if (geo.optBoolean("success")) {
                location = new double[] {geo.getDouble("latitude"), geo.getDouble("longitude")};
                return location;
            }
        } catch (Throwable t) {
            Log.w(TAG, "ip location failed: " + t);
        }
        return new double[] {DEFAULT_LAT, DEFAULT_LON};
    }

    private static String download(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(TIMEOUT_MS);
        conn.setReadTimeout(TIMEOUT_MS);
        try {
            if (conn.getResponseCode() != 200) throw new Exception("HTTP " + conn.getResponseCode());
            try (InputStream in = conn.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally {
            conn.disconnect();
        }
    }
}
