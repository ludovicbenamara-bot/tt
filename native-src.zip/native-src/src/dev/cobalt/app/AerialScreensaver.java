package dev.cobalt.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 * Aerial-video screensaver drawn over the app itself (like Aerial Views), so
 * that YouTube keeps playing the music underneath: the system screensaver
 * covers the app, and YouTube then pauses. Apple's aerial videos, muted, one
 * after another in random order, with the time and the place name. Opened
 * and closed by the page through SpectrumServer (/screensaver/...).
 */
final class AerialScreensaver {
    private static final String TAG = "TTAudio";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Random RANDOM = new Random();

    private static WeakReference<Activity> currentActivity = new WeakReference<>(null);
    private static FrameLayout layer;
    private static TextureView texture;
    private static TextView clock;
    private static TextView place;
    private static MediaPlayer player;
    private static HttpRangeSource source;
    private static volatile boolean showing = false;
    private static android.view.WindowManager windowManager;
    private static int failures = 0;

    private static final Runnable CLOCK_TICK = new Runnable() {
        @Override
        public void run() {
            if (clock == null || !showing) return;
            clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            MAIN.postDelayed(this, 10000);
        }
    };

    private AerialScreensaver() { }

    static void setActivity(Activity activity) {
        currentActivity = new WeakReference<>(activity);
    }

    static boolean isShowing() {
        return showing;
    }

    static String start() {
        MAIN.post(AerialScreensaver::show);
        return "ok";
    }

    static String stop() {
        MAIN.post(AerialScreensaver::hide);
        return "ok";
    }

    private static void show() {
        Activity activity = currentActivity.get();
        if (activity == null || showing) return;
        showing = true;
        failures = 0;
        layer = new FrameLayout(activity);
        layer.setBackgroundColor(Color.BLACK);
        texture = new TextureView(activity);
        layer.addView(texture, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        clock = label(activity, Gravity.BOTTOM | Gravity.START, 30);
        place = label(activity, Gravity.BOTTOM | Gravity.END, 22);
        layer.addView(clock);
        layer.addView(place);
        // Keys keep going to the page, which closes the screensaver.
        layer.setFocusable(false);
        layer.setClickable(false);
        // Its own window above the app (Cobalt draws the page in a surface that
        // would cover a normal view). Not focusable: keys keep going to the page.
        android.view.WindowManager.LayoutParams wp = new android.view.WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                android.graphics.PixelFormat.OPAQUE);
        // No token here: the activity's WindowManager attaches the window to it.
        wp.setTitle("TTAudioScreensaver");
        try {
            activity.getWindowManager().addView(layer, wp);
            windowManager = activity.getWindowManager();
        } catch (Throwable t) {
            Log.w(TAG, "screensaver window failed: " + t);
            showing = false;
            layer = null;
            return;
        }
        texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) { playNext(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
        CLOCK_TICK.run();
        Log.i(TAG, "screensaver shown");
    }

    private static TextView label(Activity activity, int gravity, float sp) {
        TextView t = new TextView(activity);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setShadowLayer(8, 0, 2, 0xAA000000);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        int margin = Math.round(activity.getResources().getDisplayMetrics().density * 40);
        lp.setMargins(margin, margin, margin, margin);
        t.setLayoutParams(lp);
        return t;
    }

    private static void playNext() {
        if (!showing || texture == null || !texture.isAvailable()) return;
        releasePlayer();
        final String[] video = AerialVideos.LIST[RANDOM.nextInt(AerialVideos.LIST.length)];
        place.setText(video[1]);
        try {
            source = new HttpRangeSource(AerialVideos.HOST, video[0]);
            player = new MediaPlayer();
            player.setSurface(new Surface(texture.getSurfaceTexture()));
            player.setDataSource(source);
            // Muted: the music is YouTube's.
            player.setVolume(0f, 0f);
            player.setOnPreparedListener(mp -> {
                failures = 0;
                mp.start();
            });
            player.setOnCompletionListener(mp -> playNext());
            player.setOnErrorListener((mp, what, extra) -> {
                Log.w(TAG, "screensaver video error " + what + "/" + extra + " on " + video[1]);
                if (++failures < 5) MAIN.postDelayed(AerialScreensaver::playNext, 1000);
                return true;
            });
            player.prepareAsync();
        } catch (Throwable t) {
            Log.w(TAG, "screensaver video failed: " + t);
            if (++failures < 5) MAIN.postDelayed(AerialScreensaver::playNext, 1000);
        }
    }

    private static void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Throwable ignored) { }
            player = null;
        }
        if (source != null) {
            source.close();
            source = null;
        }
    }

    private static void hide() {
        if (!showing) return;
        showing = false;
        MAIN.removeCallbacks(CLOCK_TICK);
        releasePlayer();
        if (layer != null && windowManager != null) {
            try {
                windowManager.removeViewImmediate(layer);
            } catch (Throwable t) {
                Log.w(TAG, "screensaver remove failed: " + t);
            }
        }
        windowManager = null;
        layer = null;
        texture = null;
        clock = null;
        place = null;
        Log.i(TAG, "screensaver hidden");
    }
}
