"""Add the audio visualizer bridge to the TizenTube Cobalt APK.

Usage: python3 -I build_base_apk.py <in.apk> <bridge.dex> <out.apk>

- Adds <bridge.dex> as the next classesN.dex (multidex).
- Points the manifest's application class at dev.cobalt.app.TizenTubeAudioApp,
  a subclass of the original that registers the bridge. Both names have the
  same length, so the binary manifest is patched in place.
The output still needs patch_apk.py (script URL), zipalign and apksigner.
"""
import re
import sys
import zipfile

OLD_APP = 'dev.cobalt.app.CobaltApplication'
NEW_APP = 'dev.cobalt.app.TizenTubeAudioApp'
assert len(OLD_APP) == len(NEW_APP)


def patch_manifest(data):
    count = 0
    for encoding in ('utf-16le', 'utf-8'):
        old = OLD_APP.encode(encoding)
        new = NEW_APP.encode(encoding)
        count += data.count(old)
        data = data.replace(old, new)
    if count != 1:
        sys.exit(f'Expected the application class name once in the manifest, found {count}')
    return data


def main():
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    src, dex_path, dst = sys.argv[1:]
    bridge_dex = open(dex_path, 'rb').read()

    with zipfile.ZipFile(src) as zin:
        names = zin.namelist()
        dex_numbers = [int(m.group(1) or 1) for n in names for m in [re.fullmatch(r'classes(\d*)\.dex', n)] if m]
        new_dex_name = f'classes{max(dex_numbers) + 1}.dex'
        with zipfile.ZipFile(dst, 'w') as zout:
            for info in zin.infolist():
                data = zin.read(info)
                if info.filename == 'AndroidManifest.xml':
                    data = patch_manifest(data)
                zout.writestr(info, data, compress_type=info.compress_type)
            zout.writestr(new_dex_name, bridge_dex, compress_type=zipfile.ZIP_DEFLATED)
    print(f'Added {new_dex_name}, application class -> {NEW_APP}')


if __name__ == '__main__':
    main()
